/* main.c
 * This file contains the main code for the maze-solving robot,
 * including the maze-solving and remembering algorithm.
 * There is no corresponding main.h file.
 */

/* Licensed under Simplified BSD license by Christopher Andrews.
 *
Copyright 2019 Christopher Andrews

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* Includes (with #include) code by Daniel and Jonathan Valvano licensed under the Simplified BSD license, reproduced below.
 *
Simplified BSD License (FreeBSD License)
Copyright (c) 2017, Jonathan Valvano, All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice,
   this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are
those of the authors and should not be interpreted as representing official
policies, either expressed or implied, of the FreeBSD Project.
 */

/* Includes (with #include) code licensed under the BSD 3-clause license, reproduced below.
 *
* Copyright (C) 2012 - 2017 Texas Instruments Incorporated - http://www.ti.com/
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
*
*  Redistributions of source code must retain the above copyright
*  notice, this list of conditions and the following disclaimer.
*
*  Redistributions in binary form must reproduce the above copyright
*  notice, this list of conditions and the following disclaimer in the
*  documentation and/or other materials provided with the
*  distribution.
*
*  Neither the name of Texas Instruments Incorporated nor the names of
*  its contributors may be used to endorse or promote products derived
*  from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
* A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "msp.h"
#include "Motor.h"
#include "Clock.h"
#include "Bumpers.h"
#include "GenInterrupts.h"
#include "SysTick.h"
#include "Globals.c"
#include "LineSensor.h"
#include "Buttons.h"
#include "OnBoardLEDs.h"
#include "ExternalLEDs.h"
#include "TimerAs.h"

const char *bit_rep[16] = {
    [ 0] = "0000", [ 1] = "0001", [ 2] = "0010", [ 3] = "0011",
    [ 4] = "0100", [ 5] = "0101", [ 6] = "0110", [ 7] = "0111",
    [ 8] = "1000", [ 9] = "1001", [10] = "1010", [11] = "1011",
    [12] = "1100", [13] = "1101", [14] = "1110", [15] = "1111",
}; // used to print out a value in binary

// Checks whether we have met the win condition (found the treasure).
uint8_t winCondition(uint8_t sensors)
{
    // Works by finding a 101 pattern under the robot. Ex: 11000001. Needs a 1-to-0 change and a 0-to-1 change.

    int found1_1 = 0, found0_1 = 0, found1_2 = 0; // whether the first 1, first 0, and second 1 have been found
    int i;
    for (i = 0; i < 8; i++) // for each bit in lineSensors
    {
        uint8_t currValue = (sensors << i) >> 7; // get the left-most bit after shifting and then move it to the right
        if (currValue & 0x01) // if the bit we're checking is a 1
        {
            if (!found1_1) // if we have not found the first 1
                found1_1 = 1; // we now have
            else if (found0_1) // if we have found the first 1 and the first 0
                found1_2 = 1; // we have now found the second 1
        }
        else // the bit we're checking is a 0
        {
            if (found1_1) // if we have found the first 1
                found0_1 = 1; // we have now found the first 0
        }
        if (found1_1 && found0_1 && found1_2) // if we've found all 3 bit changes
            break; // we've found the treasure!
    }

    if (found1_1 && found0_1 && found1_2) // if we've found all 3 changes
        return 1; // return that we've found the treasure
    return 0; // otherwise we didn't find the treasure yet
}

// Moves the robot forward approximately half its length.
inline void MoveForwardHalfCar()
{
    Motor_ForwardSimple(MOVE_SPEED, 27 * 1675 / MOVE_SPEED);
}

// Moves the robot forward slightly under half its length.
inline void MoveForwardUnderHalfCar()
{
    Motor_ForwardSimple(MOVE_SPEED, 22 * 1675 / MOVE_SPEED);
}

// Potentially updates the list of turns based on the last 3 turns in it.
void updateTurns()
{
    if (nextTurnInd <= 2) // if there aren't enough turns yet to do anything (2 or fewer turns)
        return;

    char lastTurns[3]; // array that will store the last 3 turns made
    lastTurns[0] = turns[nextTurnInd - 3]; // 3rd last turn
    lastTurns[1] = turns[nextTurnInd - 2]; // 2nd last turn
    lastTurns[2] = turns[nextTurnInd - 1]; // last turn

    // Go through the replacement rules to replace turns with correct turns
    if ((lastTurns[0] == STRAIGHT_CHAR) && (lastTurns[1] == UTURN_CHAR) && (lastTurns[2] == LEFT_CHAR)) // SUL -> R
    {
        // Pop off the last 3 turns and replace them with a single turn
        nextTurnInd -= 2;
        turns[nextTurnInd - 1] = RIGHT_CHAR;
    }
    else if ((lastTurns[0] == LEFT_CHAR) && (lastTurns[1] == UTURN_CHAR) && (lastTurns[2] == LEFT_CHAR)) // LUL -> S
    {
        // Pop off the last 3 turns and replace them with a single turn
        nextTurnInd -= 2;
        turns[nextTurnInd - 1] = STRAIGHT_CHAR;
    }
    else if ((lastTurns[0] == RIGHT_CHAR) && (lastTurns[1] == UTURN_CHAR) && (lastTurns[2] == LEFT_CHAR)) // RUL -> U
    {
        // Pop off the last 3 turns and replace them with a single turn
        nextTurnInd -= 2;
        turns[nextTurnInd - 1] = UTURN_CHAR;
    }
    else if ((lastTurns[0] == LEFT_CHAR) && (lastTurns[1] == UTURN_CHAR) && (lastTurns[2] == STRAIGHT_CHAR)) // LUS -> R
    {
        // Pop off the last 3 turns and replace them with a single turn
        nextTurnInd -= 2;
        turns[nextTurnInd - 1] = RIGHT_CHAR;
    }
}

// Called when the program starts.
// Contains the main logic for solving the maze.
void main(void)
{
    WDT_A->CTL = WDT_A_CTL_PW | WDT_A_CTL_HOLD; // stop watchdog timer

	// Initialize everything
	DisableInterrupts();
	state = STOPPED; // stopped by default
	Clock_Init48MHz(); // run at 48MHz
	Motor_InitSimple(); // initialize the wheel motors
	BumpInt_Init(); // initialize the bump sensors
	LineSensor_Init(); // initialize the line/light sensors
	OnBoardButtons_Init(); // initialize the on-board buttons for changing the robot's state (running, stopping, solutioning)
	OnBoardLED_Init(); // initialize the on-board LEDs
	ExtLED_Init(); // initialize the 3 external LEDs on top of the robot
	nextTurnInd = 0; // initialize the turn list as empty
	nextSolnTurnInd = 0; // initialize the first turn to take when showing the solution as 0
	TimerA0_Init(); // initialize but don't start Timer A0
	SysTick_Init(); // initialize the SysTick timer with interrupts
	EnableInterrupts();

	while (1) // forever
	{
	    uint8_t sensors = lineSensors; // get the current value of lineSensors in case it is updated mid-loop
	    if ((state == STOPPED) || (state == WIN)) // if the robot should not be running
	    {
	        SysTick_DisableInterrupt(); // disable the SysTick interrupt
	        lineSensors = 0x18; // so the robot goes forward when enabled instead of moving randomly
	        WaitForInterrupt(); // wait for a button press
	        continue; // in case a non-button interrupt interrupts here, just go back through the while-loop
	    }
	    else if (state == RUNNING) // robot should be solving the maze
	    {
            // Run the maze solver
            //printf("%s%s\n", bit_rep[lineSensors >> 4], bit_rep[lineSensors & 0x0F]); // print line sensor value in binary
            if (sensors == 0x00) // if the sensors are all white (off the line)
            {
                Motor_ForwardSimple(MOVE_SPEED, 25); // move forward a tiny bit so the line sensor is in a good spot after turning around
                Motor_Spin180(); // turn around (where we'll hopefully find the line)
                Clock_Delay1ms(10); // wait 0.1 sec
                lineSensors = LineSensor_Read(); // re-read the line sensor so that we don't use an outdated value

                // Update the list of turns
                turns[nextTurnInd] = UTURN_CHAR;
                nextTurnInd++;
            }
            else if (sensors == 0xFF) // if the sensors are all black (T or 4-way intersection)
            {
                ExtLED_LeftOn(); // turn on the left top LED
                TimerA0_Start(&ExtLED_LeftToggle, 0xEF00, 6); // flash the top left LED at 0.5Hz while turning (flash up to 6/2=3 times)
                MoveForwardHalfCar(); // align the wheels with the crossing line
                Motor_SpinLeft90(); // take the left path
                Clock_Delay1ms(10); // wait 0.1 sec
                TimerA0_Stop(); // stop flashing the top left LED
                ExtLED_LeftOff(); // turn off the left top LED
                lineSensors = LineSensor_Read(); // re-read the line sensor so that we don't use an outdated value

                // Update the list of turns
                turns[nextTurnInd] = LEFT_CHAR;
                nextTurnInd++;
                updateTurns();
            }
            else if (winCondition(sensors)) // if the win condition has happened
            {
                Motor_ForwardSimple(MOVE_SPEED, 5); // move forward a bit
                Clock_Delay1ms(10); // wait 0.1 sec
                sensors = lineSensors = LineSensor_Read(); // re-read the line sensor to see if it's still a win condition and not a false positive
                if (winCondition(sensors)) // if it's still a win condition
                {
                    state = WIN; // set the robot's state to WIN because it found the treasure
                    Motor_StopSimple(); // stop the motors

                    // Flash the top LEDs at 1Hz for 5 seconds.
                    ExtLED_AllOn(); // turn on all 3 top LEDs
                    TimerA0_Start(&ExtLED_AllToggle, 0x7780, 9); // start Timer A0 to handle flashing
                }
            }
            else if ((sensors & 0xE0) == 0xE0) // if there's a left turn available
            {
                ExtLED_LeftOn(); // turn on the left top LED
                TimerA0_Start(&ExtLED_LeftToggle, 0xEF00, 6); // flash the top left LED at 0.5Hz while turning (flash up to 6/2=3 times)
                MoveForwardHalfCar(); // align the wheels with the crossing line
                sensors = lineSensors = LineSensor_Read(); // re-read the line sensors
                if (sensors != 0x00) // if the line sensors are not all white, meaning there's a forward option (this is an intersection and not just a left turn)
                {
                    // Update the list of turns
                    turns[nextTurnInd] = LEFT_CHAR;
                    nextTurnInd++;
                    updateTurns();
                }
                Motor_SpinLeft90(); // take the left path
                Clock_Delay1ms(10); // wait 0.1 sec
                TimerA0_Stop(); // stop flashing the top left LED
                ExtLED_LeftOff(); // turn off the left top LED
                lineSensors = LineSensor_Read(); // re-read the line sensor so that we don't use an outdated value
            }
            else if ((sensors & 0x07) == 0x07) // if there's a possible straightAndRight intersection or a right turn
            {
                Motor_ForwardSimple(MOVE_SPEED, 5); // move forward a bit and check if it's still only a right turn or a horizontal line (still won't know if straight is an option yet)
                sensors = lineSensors = LineSensor_Read(); // re-read the line sensors
                if ((sensors & 0xE0) != 0xE0) // if it's still a straightAndRight intersection or a right turn (the left 3 sensors are not all on)
                {
                    MoveForwardUnderHalfCar(); // align the wheels with the crossing line
                    Clock_Delay1ms(10); // wait 0.1 sec
                    sensors = lineSensors = LineSensor_Read(); // re-read the line sensors
                    if (sensors == 0x00) // if the line sensors are all white, meaning there's no forward option
                    {
                        ExtLED_RightOn(); // turn on the right top LED
                        TimerA0_Start(&ExtLED_RightToggle, 0xEF00, 6); // flash the top right LED at 0.5Hz while turning (flash up to 6/2=3 times)
                        Motor_SpinRight90(); // there was only a right turn, so turn right
                        Clock_Delay1ms(10); // wait 0.1 sec
                        TimerA0_Stop(); // stop flashing the top right LED
                        ExtLED_RightOff(); // turn off the right top LED
                        lineSensors = LineSensor_Read(); // re-read the line sensor so that we don't use an outdated value
                    }
                    else // take the straight option
                    {
                        // Update the list of turns
                        turns[nextTurnInd] = STRAIGHT_CHAR;
                        nextTurnInd++;
                        updateTurns();
                    }
                }
            }
            // None of the special if-clauses above were taken, so now just follow the black line.
            else if ((sensors & 0x80) == 0x80) // if sensor 7 is black
            {
                Motor_RightSimple(MOVE_SPEED, 2); // turn left a significant amount
                Motor_ForwardSimple(MOVE_SPEED, 2); // go forward a bit
            }
            else if ((sensors & 0x40) == 0x40) // if sensor 6 is black
            {
                Motor_RightSimple(MOVE_SPEED, 2); // turn left a medium amount
                Motor_ForwardSimple(MOVE_SPEED, 3); // go forward a bit
            }
            else if ((sensors & 0x20) == 0x20) // if sensor 5 is black
            {
                Motor_RightSimple(MOVE_SPEED, 1); // turn left a small amount
                Motor_ForwardSimple(MOVE_SPEED, 2); // go forward a bit
            }
            else if ((sensors & 0x01) == 0x01) // if sensor 0 is black
            {
                Motor_LeftSimple(MOVE_SPEED, 2); // turn right a significant amount
                Motor_ForwardSimple(MOVE_SPEED, 2); // go forward a bit
            }
            else if ((sensors & 0x02) == 0x02) // if sensor 1 is black
            {
                Motor_LeftSimple(MOVE_SPEED, 2); // turn right a medium amount
                Motor_ForwardSimple(MOVE_SPEED, 3); // go forward a bit
            }
            else if ((sensors & 0x04) == 0x04) // if sensor 2 is black
            {
                Motor_LeftSimple(MOVE_SPEED, 1); // turn right a small amount
                Motor_ForwardSimple(MOVE_SPEED, 2); // go forward a bit
            }
            else if (((sensors & 0x10) == 0x10) || // if sensor 4 is black
                     ((sensors & 0x08) == 0x08)) // or if sensor 3 is black
            {
                Motor_ForwardSimple(MOVE_SPEED, 2);
            }
            // No else-clause. Just do nothing if none of the above are true. Shouldn't ever happen, though.
	    }
	    else if (state == SOLUTIONING) // if the robot should be showing the solution to the maze
	    {
	        if ((nextSolnTurnInd == 0) && (turns[0] == UTURN_CHAR) && (nextTurnInd != 0)) // if we're on the first turn and it's a u-turn and there is at least 1 turn required in the solution
	        {
	            // Turn around
	            MoveForwardHalfCar(); MoveForwardHalfCar(); // move forward a full car length so the line sensor is in a good spot after turning around
                Motor_Spin180(); // turn around (where we'll hopefully find the line)
                Clock_Delay1ms(10); // wait 0.1 sec
                sensors = lineSensors = LineSensor_Read(); // re-read the line sensor so that we don't use an outdated value
                nextSolnTurnInd++; // increment the solutioning turn index so the next turn is correct
	        }
	        else if (nextSolnTurnInd == nextTurnInd) // if we've shown everything we have figured out in the maze so far
	        {
	            state = RUNNING; // set to the robot to the RUNNING state so that it can continue solving the maze
	        }
	        else if (winCondition(sensors)) // if the win condition has happened
            {
                Motor_ForwardSimple(MOVE_SPEED, 5); // move forward a bit
                Clock_Delay1ms(10); // wait 0.1 sec
                sensors = lineSensors = LineSensor_Read(); // re-read the line sensor to see if it's still a win condition and not a false positive
                if (winCondition(sensors)) // if it's still a win condition
                {
                    state = WIN; // set the robot's state to WIN because it found the treasure
                    Motor_StopSimple(); // stop the motors

                    // Flash the top LEDs at 1Hz for 5 seconds.
                    ExtLED_AllOn(); // turn on all 3 top LEDs
                    TimerA0_Start(&ExtLED_AllToggle, 0x7780, 9); // start Timer A0 to handle flashing
                }
            }
            else if (((sensors & 0xE0) == 0xE0) || ((sensors & 0x07) == 0x07)) // if there's a left and/or right turn available (there's a potential intersection ahead)
            {
                Motor_ForwardSimple(MOVE_SPEED, 5); // move forward a bit
                Clock_Delay1ms(10); // wait 0.1 sec
                sensors = lineSensors = LineSensor_Read(); // re-read the line sensor to ensure left and right get set properly by being completely on the crossing line
                uint8_t left = ((sensors & 0xE0) == 0xE0); // whether a left turn is available
                uint8_t right = ((sensors & 0x07) == 0x07); // whether a right turn is available
                uint8_t straight = 0; // whether straight is an option (can't determine until we move forward and check)
                MoveForwardHalfCar(); // align the wheels with the crossing line
                sensors = lineSensors = LineSensor_Read(); // re-read the line sensor to see if forward is an option
                if (sensors != 0x00) // if straight is an option
                    straight = 1; // straight is an option
                if ((left && straight) || (left && right) || (straight && right)) // if there are at least 2 options for where to go at this potential intersection
                {
                    // We are at an intersection and not just a turn, so obey the next turn command
                    if (turns[nextSolnTurnInd] == LEFT_CHAR) // if we should turn left at this intersection
                    {
                        ExtLED_LeftOn(); // turn on the left top LED
                        TimerA0_Start(&ExtLED_LeftToggle, 0xEF00, 6); // flash the top left LED at 0.5Hz while turning (flash up to 6/2=3 times)
                        Motor_SpinLeft90(); // take the left path
                        Clock_Delay1ms(10); // wait 0.1 sec
                        TimerA0_Stop(); // stop flashing the top left LED
                        ExtLED_LeftOff(); // turn off the left top LED
                        lineSensors = LineSensor_Read(); // re-read the line sensor so that we don't use an outdated value
                        nextSolnTurnInd++; // increment the solutioning turn index so the next turn is correct
                    }
                    else if (turns[nextSolnTurnInd] == RIGHT_CHAR) // if we should turn right at this intersection
                    {
                        ExtLED_RightOn(); // turn on the right top LED
                        TimerA0_Start(&ExtLED_RightToggle, 0xEF00, 6); // flash the top right LED at 0.5Hz while turning (flash up to 6/2=3 times)
                        Motor_SpinRight90(); // take the left path
                        Clock_Delay1ms(10); // wait 0.1 sec
                        TimerA0_Stop(); // stop flashing the top right LED
                        ExtLED_RightOff(); // turn off the right top LED
                        lineSensors = LineSensor_Read(); // re-read the line sensor so that we don't use an outdated value
                        nextSolnTurnInd++; // increment the solutioning turn index so the next turn is correct
                    }
                    else // we should go straight at this intersection
                    {
                        // Do nothing because the robot will go straight because of the line sensor value anyway.
                        nextSolnTurnInd++; // increment the solutioning turn index so the next turn is correct
                    }
                }
                else // we are not at an intersection, just a turn
                {
                    if (left) // if it's a left turn
                    {
                        ExtLED_LeftOn(); // turn on the left top LED
                        TimerA0_Start(&ExtLED_LeftToggle, 0xEF00, 6); // flash the top left LED at 0.5Hz while turning (flash up to 6/2=3 times)
                        Motor_SpinLeft90(); // take the left path
                        Clock_Delay1ms(10); // wait 0.1 sec
                        TimerA0_Stop(); // stop flashing the top left LED
                        ExtLED_LeftOff(); // turn off the left top LED
                        lineSensors = LineSensor_Read(); // re-read the line sensor so that we don't use an outdated value
                    }
                    else // it's a right turn (straight is not an option)
                    {
                        ExtLED_RightOn(); // turn on the right top LED
                        TimerA0_Start(&ExtLED_RightToggle, 0xEF00, 6); // flash the top right LED at 0.5Hz while turning (flash up to 6/2=3 times)
                        Motor_SpinRight90(); // take the left path
                        Clock_Delay1ms(10); // wait 0.1 sec
                        TimerA0_Stop(); // stop flashing the top right LED
                        ExtLED_RightOff(); // turn off the right top LED
                        lineSensors = LineSensor_Read(); // re-read the line sensor so that we don't use an outdated value
                    }
                }
            }
            // None of the special if-clauses above were taken, so now just follow the black line.
            else if ((sensors & 0x80) == 0x80) // if sensor 7 is black
            {
                Motor_RightSimple(MOVE_SPEED, 2); // turn left a significant amount
                Motor_ForwardSimple(MOVE_SPEED, 2); // go forward a bit
            }
            else if ((sensors & 0x40) == 0x40) // if sensor 6 is black
            {
                Motor_RightSimple(MOVE_SPEED, 2); // turn left a medium amount
                Motor_ForwardSimple(MOVE_SPEED, 3); // go forward a bit
            }
            else if ((sensors & 0x20) == 0x20) // if sensor 5 is black
            {
                Motor_RightSimple(MOVE_SPEED, 1); // turn left a small amount
                Motor_ForwardSimple(MOVE_SPEED, 2); // go forward a bit
            }
            else if ((sensors & 0x01) == 0x01) // if sensor 0 is black
            {
                Motor_LeftSimple(MOVE_SPEED, 2); // turn right a significant amount
                Motor_ForwardSimple(MOVE_SPEED, 2); // go forward a bit
            }
            else if ((sensors & 0x02) == 0x02) // if sensor 1 is black
            {
                Motor_LeftSimple(MOVE_SPEED, 2); // turn right a medium amount
                Motor_ForwardSimple(MOVE_SPEED, 3); // go forward a bit
            }
            else if ((sensors & 0x04) == 0x04) // if sensor 2 is black
            {
                Motor_LeftSimple(MOVE_SPEED, 1); // turn right a small amount
                Motor_ForwardSimple(MOVE_SPEED, 2); // go forward a bit
            }
            else if (((sensors & 0x10) == 0x10) || // if sensor 4 is black
                     ((sensors & 0x08) == 0x08)) // or if sensor 3 is black
            {
                Motor_ForwardSimple(MOVE_SPEED, 2);
            }
            // No else-clause. Just do nothing if none of the above are true. Shouldn't ever happen, though.
	    }
	    // No else-clause here since state should always be one of the defined states.
	}
}
