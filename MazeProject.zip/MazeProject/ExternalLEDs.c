/* ExternalLEDs.c
 * This file contains code related to the 3 LEDs
 * that sit on the breadboard on the top of the robot,
 * including initialization, turning on, turning off,
 * and toggling.
 */

/* Licensed under Simplified BSD license by Christopher Andrews.
 *
Copyright 2019 Christopher Andrews

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* Includes (with #include) code licensed under the BSD 3-clause license, reproduced below.
 *
* Copyright (C) 2012 - 2017 Texas Instruments Incorporated - http://www.ti.com/
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
*
*  Redistributions of source code must retain the above copyright
*  notice, this list of conditions and the following disclaimer.
*
*  Redistributions in binary form must reproduce the above copyright
*  notice, this list of conditions and the following disclaimer in the
*  documentation and/or other materials provided with the
*  distribution.
*
*  Neither the name of Texas Instruments Incorporated nor the names of
*  its contributors may be used to endorse or promote products derived
*  from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
* A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "msp.h"
#include "ExternalLEDs.h"

// The 3 external LEDs follow positive logic and are on ports:
// Middle: P6.4
// Left: P6.5
// Right: P6.6

// Initializes the 3 external LEDs on top of the robot.
void ExtLED_Init()
{
    P6->SEL0 &= ~0x70;
    P6->SEL1 &= ~0x70; // set the 3 ports as GPIOs
    P6->DIR |= 0x70; // make the pins outputs
    P6->OUT &= ~0x70; // turn off the LEDs by default
}

// Turns off the left of the 3 external LEDs.
inline void ExtLED_LeftOff()
{
    P6->OUT &= ~0x20;
}

// Turns on the left of the 3 external LEDs.
inline void ExtLED_LeftOn()
{
    P6->OUT |= 0x20;
}

// Toggles the left of the 3 external LEDs.
inline void ExtLED_LeftToggle()
{
    P6->OUT ^= 0x20;
}

// Turns off the middle of the 3 external LEDs.
inline void ExtLED_MiddleOff()
{
    P6->OUT &= ~0x10;
}

// Turns on the middle of the 3 external LEDs.
inline void ExtLED_MiddleOn()
{
    P6->OUT |= 0x10;
}

// Toggles the middle of the 3 external LEDs.
inline void ExtLED_MiddleToggle()
{
    P6->OUT ^= 0x10;
}

// Turns off the right of the 3 external LEDs.
inline void ExtLED_RightOff()
{
    P6->OUT &= ~0x40;
}

// Turns on the right of the 3 external LEDs.
inline void ExtLED_RightOn()
{
    P6->OUT |= 0x40;
}

// Toggles the right of the 3 external LEDs.
inline void ExtLED_RightToggle()
{
    P6->OUT ^= 0x40;
}

// Turns all 3 external LEDs off.
inline void ExtLED_AllOff()
{
    P6->OUT &= ~0x70;
}

// Turns all 3 external LEDs on.
inline void ExtLED_AllOn()
{
    P6->OUT |= 0x70;
}

// Toggles all 3 external LEDs.
inline void ExtLED_AllToggle()
{
    P6->OUT ^= 0x70;
}
