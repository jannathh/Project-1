/* Bumpers.c
 * This file contains code related to bumpers, including
 * initialization, reading the sensors, and interrupt handling.
 */

/* Licensed under Simplified BSD license by Christopher Andrews.
 *
Copyright 2019 Christopher Andrews

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* Includes (with #include) code by Daniel and Jonathan Valvano licensed under the Simplified BSD license, reproduced below.
 *
Simplified BSD License (FreeBSD License)
Copyright (c) 2017, Jonathan Valvano, All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice,
   this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are
those of the authors and should not be interpreted as representing official
policies, either expressed or implied, of the FreeBSD Project.
 */

/* Includes (with #include) code licensed under the BSD 3-clause license, reproduced below.
 *
* Copyright (C) 2012 - 2017 Texas Instruments Incorporated - http://www.ti.com/
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
*
*  Redistributions of source code must retain the above copyright
*  notice, this list of conditions and the following disclaimer.
*
*  Redistributions in binary form must reproduce the above copyright
*  notice, this list of conditions and the following disclaimer in the
*  documentation and/or other materials provided with the
*  distribution.
*
*  Neither the name of Texas Instruments Incorporated nor the names of
*  its contributors may be used to endorse or promote products derived
*  from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
* A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "msp.h"
#include "Bumpers.h"
#include "GenInterrupts.h"
#include "Motor.h"
#include "SysTick.h"
#include "ExternalLEDs.h"
#include "Globals.c"
#include "OnBoardLEDs.h"
#include "LineSensor.h"

// Initialize Bump sensors.
// Bit 0 = right-most sensor.
// Bit 5 = left-most sensor.
void BumpInt_Init()
{
    // Ports: 4.0, 4.2, 4.3, 4.5, 4.6, 4.7
    // Activate on falling edge (on touch).

    P4->SEL0 &= ~0xED; // ~(1110 1101)
    P4->SEL1 &= ~0xED; // makes the above ports GPIOs
    P4->DIR &= ~0xED; // makes the above ports inputs
    P4->REN |= 0xED; // activate pull resistors
    P4->OUT |= 0xED; // make the pull resistors pull-up

    // Make the bumper switches send interrupts
    P4->IES |= 0xED; // falling edge
    P4->IFG &= ~0xED; // clear interrupt flag for bumper switches
    P4->IE |= 0xED; // arm interrupt on bumpers
    NVIC->IP[9] = (NVIC->IP[9] & 0xFF00FFFF) | 0x00400000; // priority 2
    NVIC->ISER[1] |= 0x00000040; // enable interrupt #38
}

// Read current state of 6 switches.
// Returns a 6-bit positive logic result (0 to 63).
// bit 5 Bump5
// bit 4 Bump4
// bit 3 Bump3
// bit 2 Bump2
// bit 1 Bump1
// bit 0 Bump0
uint8_t Bump_Read(void)
{
    // Ports: 4.0, 4.2, 4.3, 4.5, 4.6, 4.7
    // 4.0 = Bump0 = right-most, 4.7 = Bump5 = left-most
    // Note that the bumper switches are "1" when not pressed, "0" when pressed.

    uint8_t result = 0;
    result |= (P4->IN & 0x01); // bump0
    result |= ((P4->IN & 0x04) >> 1); // bump1
    result |= ((P4->IN & 0x08) >> 1); // bump2
    result |= ((P4->IN & 0x20) >> 2); // bump3
    result |= ((P4->IN & 0x40) >> 2); // bump4
    result |= ((P4->IN & 0x80) >> 2); // bump5

    return result;
}

// Handles bumper switches getting hit.
// We do not care about critical section/race conditions.
// Triggered on touch, falling edge.
void PORT4_IRQHandler(void)
{
    P4->IFG &= ~0xED; // clear all the bumper interrupt flags (acknowledge interrupt)
    uint8_t bumperState = Bump_Read(); // get the state of the bumper switches
    if (bumperState != 0x3F) // if a bumper switch is pressed
    {
        ExtLED_MiddleOn(); // turn on the middle top LED
        Motor_BackwardSimple(2000, 20); // reverse a bit
        Motor_Spin180(); // turn the robot around
        ExtLED_MiddleOff(); // turn off the middle top LED
        lineSensors = LineSensor_Read(); // re-read the line sensor so we don't use an outdated value

        // Update the list of turns
        turns[nextTurnInd] = UTURN_CHAR;
        nextTurnInd++;
    }
}
