/* SysTick.c
 * This file contains code related to the SysTick timer, including
 * initialization, interrupt handling, and interrupt enabling and
 * disabling. SysTick is used to periodically read the line sensor
 * on the robot.
 */

/* Licensed under Simplified BSD license by Christopher Andrews.
 *
Copyright 2019 Christopher Andrews

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* Includes (with #include) code licensed under the BSD 3-clause license, reproduced below.
 *
* Copyright (C) 2012 - 2017 Texas Instruments Incorporated - http://www.ti.com/
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
*
*  Redistributions of source code must retain the above copyright
*  notice, this list of conditions and the following disclaimer.
*
*  Redistributions in binary form must reproduce the above copyright
*  notice, this list of conditions and the following disclaimer in the
*  documentation and/or other materials provided with the
*  distribution.
*
*  Neither the name of Texas Instruments Incorporated nor the names of
*  its contributors may be used to endorse or promote products derived
*  from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
* A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "msp.h"
#include "SysTick.h"
#include "Globals.c"
#include "LineSensor.h"
#include "OnBoardLEDs.h"

//#define SysTickInterval 0x00927C00 // 0.2 sec
//#define SysTickInterval 0x00493E00 // 0.1 sec
//#define SysTickInterval 0x00249F00 // 0.05 sec
#define SysTickInterval 0x00124F80 // 0.025 sec

// Initializes SysTick to send an interrupt every SysTickInterval clock cycles, and starts SysTick.
void SysTick_Init(void)
{
    SysTick->LOAD = SysTickInterval; // load with the interval we want
    //SysTick->CTRL = 0x00000005; // enable SysTick with no interrupts
    SysTick->CTRL = 0x7; // enable SysTick with interrupts
    SCB->SHP[11] = 4 << 5; // priority 4
}

// Called every time SysTick sends an interrupt.
void SysTick_Handler()
{
    // SysTick automatically acknowledges (resets) the interrupt flag
    lineSensors = LineSensor_Read(); // read the line sensor
    SysTick_Restart(); // reload SysTick
}

// Disables the interrupt enable flag in SysTick.
inline void SysTick_DisableInterrupt()
{
    SysTick->CTRL = 0x5; // enable SysTick with no interrupts
}

// Sets the interrupt enable flag in SysTick.
inline void SysTick_EnableInterrupt()
{
    SysTick->CTRL = 0x7; // enable SysTick with interrupts
}

// Loads SysTickInterval into SysTick so it can restart.
inline void SysTick_Restart()
{
    SysTick->LOAD = SysTickInterval; // load with the interval we want
}
