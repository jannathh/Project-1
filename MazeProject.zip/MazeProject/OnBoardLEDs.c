/* OnBoardLEDs.c
 * This file contains code related to the LEDs on the Launchpad board,
 * including initialization, turning on, turning off, and toggling.
 */

/* Licensed under Simplified BSD license by Christopher Andrews.
 *
Copyright 2019 Christopher Andrews

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* Includes (with #include) code licensed under the BSD 3-clause license, reproduced below.
 *
* Copyright (C) 2012 - 2017 Texas Instruments Incorporated - http://www.ti.com/
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
*
*  Redistributions of source code must retain the above copyright
*  notice, this list of conditions and the following disclaimer.
*
*  Redistributions in binary form must reproduce the above copyright
*  notice, this list of conditions and the following disclaimer in the
*  documentation and/or other materials provided with the
*  distribution.
*
*  Neither the name of Texas Instruments Incorporated nor the names of
*  its contributors may be used to endorse or promote products derived
*  from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
* A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "msp.h"
#include "OnBoardLEDs.h"

// Initializes the 4 on-board LEDs.
void OnBoardLED_Init()
{
    // Set up the single red LED
    P1->SEL0 &= ~0x01;
    P1->SEL1 &= ~0x01; // P1.0 is GPIO
    P1->DIR |= 0x01; // P1.0 is output
    P1->OUT &= ~0x01; // turn off by default

    // Set up the 3-piece RGB LED
    P2->SEL0 &= ~0x07;
    P2->SEL1 &= ~0x07; // P2.0, P2.1, P2.2 are GPIO
    P2->DIR |= 0x07; // outputs
    P2->OUT &= ~0x07; // turn off by default
}

// Toggles the single red LED on P1.0.
void LED1_Red_Toggle()
{
    P1->OUT ^= 0x01; // toggle the red LED
}

// Toggles the red LED in the combined 3-piece LED.
void LED3_Red_Toggle()
{
    P2->OUT ^= 0x01;
}

// Toggles the green LED in the combined 3-piece LED.
void LED3_Green_Toggle()
{
    P2->OUT ^= 0x02;
}

// Toggles the blue LED in the combined 3-piece LED.
void LED3_Blue_Toggle()
{
    P2->OUT ^= 0x04;
}

// Turns off the single red LED.
void LED1_Red_Off()
{
    P1->OUT &= ~0x01;
}

// Turns on the single red LED.
void LED1_Red_On()
{
    P1->OUT |= 0x01;
}

// Turns off the red LED in the combined 3-piece LED.
void LED3_Red_Off()
{
    P2->OUT &= ~0x01;
}

// Turns on the red LED in the combined 3-piece LED.
void LED3_Red_On()
{
    P2->OUT |= 0x01;
}

// Turns off the green LED in the combined 3-piece LED.
void LED3_Green_Off()
{
    P2->OUT &= ~0x02;
}

// Turns on the green LED in the combined 3-piece LED.
void LED3_Green_On()
{
    P2->OUT |= 0x02;
}

// Turns off the blue LED in the combined 3-piece LED.
void LED3_Blue_Off()
{
    P2->OUT &= ~0x04;
}

// Turns on the blue LED in the combined 3-piece LED.
void LED3_Blue_On()
{
    P2->OUT |= 0x04;
}
