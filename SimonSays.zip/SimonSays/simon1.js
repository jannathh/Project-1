let level=0, highest=0, p=document.querySelector('p');
const rand=()=>(Math.floor(Math.random()*4));
let red=document.querySelector('.red'), blue=document.querySelector('.blue'), 
green=document.querySelector('.green'), yellow=document.querySelector('.yellow');
let arr=[red,green,yellow,blue], flashes=[], answer=[];
function flash(){
  setTimeout(function (){
    let colour=arr[rand()];
    flashes.push(colour);
    colour.classList.toggle('flash');
    setTimeout(()=>{colour.classList.toggle('flash');}, 100);
  },1000);
}
function wrong(){
  if(highest<level) highest=level;
  document.body.classList.toggle('wrong');
  setTimeout(()=>{document.body.classList.toggle('wrong');}, 100);
  p.innerHTML=`Game over. Score: ${level} <br>High Score: ${highest}<br>Press any key to try again`
}
function check(arr1,arr2){
  let result=true;
  let len=Math.min(arr1.length,arr2.length);
  for(let i=0;i<len;i++){
    if(arr1[i]!=arr2[i]) result=false;
  }
  return result;
}
for(let i=0;i<4;i++){
  arr[i].onclick=()=>{
    if(p.innerText==`Level ${level}`){
      answer.push(arr[i]);
      arr[i].classList.toggle('flash');
      setTimeout(()=>{arr[i].classList.toggle('flash');}, 100);
      if(!check(flashes,answer)){
        answer=[];
        flashes=[];
        wrong();
        level=0;
      }
      else if(answer.length===flashes.length){
        answer=[];
        level++;
        p.innerText=`Level ${level}`;
        flash();
      }
    }
  }
}

window.addEventListener('keypress',()=>{
  level++;
  p.innerText=`Level ${level}`;
  flash();
})

let dark=document.querySelector('button');
dark.onclick=()=>{
  document.body.classList.toggle('dark');
  dark.classList.toggle('flash');
}